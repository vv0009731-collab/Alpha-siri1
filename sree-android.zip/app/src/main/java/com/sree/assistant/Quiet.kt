package com.sree.assistant

import android.content.Context
import android.media.AudioManager

/** Mutes the system "ding" that Android plays every time speech recognition starts. */
object Quiet {
    private val streams = intArrayOf(AudioManager.STREAM_MUSIC, AudioManager.STREAM_NOTIFICATION, AudioManager.STREAM_SYSTEM)
    private fun am(c: Context) = c.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    fun mute(c: Context) { for (s in streams) try { am(c).adjustStreamVolume(s, AudioManager.ADJUST_MUTE, 0) } catch (e: Exception) {} }
    fun unmute(c: Context) { for (s in streams) try { am(c).adjustStreamVolume(s, AudioManager.ADJUST_UNMUTE, 0) } catch (e: Exception) {} }
}
