package com.sree.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import java.util.Locale

class WakeService : Service() {
    companion object { @Volatile var on = false }
    private var sr: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private val h = Handler(Looper.getMainLooper())
    private var awaiting = false
    private val wake = Regex("(sree|shree|sri|siri|श्री|सिरी)")

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, s: Int): Int {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("sree", "Sree", NotificationManager.IMPORTANCE_LOW))
        val pi = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, "sree").setContentTitle("Sree sun rahi hai").setContentText("Hey Sree bolo")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now).setContentIntent(pi).build()
        if (Build.VERSION.SDK_INT >= 30) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE) else startForeground(1, n)
        on = true
        if (tts == null) tts = TextToSpeech(this) { tts?.language = Locale("hi", "IN") }
        h.post { listen() }
        return START_STICKY
    }

    private fun listen() {
        if (!on) return
        sr?.destroy()
        sr = SpeechRecognizer.createSpeechRecognizer(this)
        sr?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(p: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(v: Float) {}
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onError(e: Int) { h.postDelayed({ listen() }, 700) }
            override fun onResults(r: Bundle?) {
                r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let { handle(it.lowercase()) }
                h.postDelayed({ listen() }, 400)
            }
            override fun onPartialResults(p: Bundle?) {}
            override fun onEvent(t: Int, p: Bundle?) {}
        })
        sr?.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN"))
    }

    private fun handle(t: String) {
        val m = wake.find(t)
        val cmd = when {
            m != null -> t.substring(m.range.last + 1).trim(' ', ',')
            awaiting -> t
            else -> return
        }
        if (cmd.isEmpty()) { awaiting = true; ToneGenerator(AudioManager.STREAM_MUSIC, 80).startTone(ToneGenerator.TONE_PROP_BEEP); return }
        awaiting = false
        val reply = Commands.run(this, cmd)
        if (reply != null) { tts?.speak(reply, TextToSpeech.QUEUE_FLUSH, null, "s"); return }
        val pi = PendingIntent.getActivity(this, 2,
            Intent(this, MainActivity::class.java).putExtra("q", cmd).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val n = Notification.Builder(this, "sree").setContentTitle("Sree: jawab ke liye tap karo").setContentText(cmd)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now).setContentIntent(pi).setAutoCancel(true).build()
        getSystemService(NotificationManager::class.java).notify(2, n)
        tts?.speak("Jawab ke liye notification dabao", TextToSpeech.QUEUE_FLUSH, null, "s")
    }

    override fun onDestroy() {
        on = false; h.removeCallbacksAndMessages(null); sr?.destroy(); tts?.shutdown(); super.onDestroy()
    }
}
