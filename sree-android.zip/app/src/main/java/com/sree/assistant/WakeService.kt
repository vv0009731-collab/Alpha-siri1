package com.sree.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

class WakeService : Service() {
    companion object { @Volatile var on = false }
    private var sr: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private val h = Handler(Looper.getMainLooper())
    private var convoUntil = 0L
    private var speaking = false
    private var busy = false
    private val wakeWords = setOf("sree", "shree", "sri", "shri", "siri", "shiri", "sriya", "seri", "sirri", "स्री", "श्री", "सिरी", "सीरी", "शिरी", "श्रि", "शरी", "सरी")

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, s: Int): Int {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("sree", "Sree", NotificationManager.IMPORTANCE_LOW))
        val pi = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, "sree").setContentTitle("Sree sun rahi hai").setContentText("Hey Sree bolo, phir seedha baat karo")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now).setContentIntent(pi).build()
        if (Build.VERSION.SDK_INT >= 30) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE) else startForeground(1, n)
        on = true
        if (tts == null) tts = TextToSpeech(this) { st ->
            if (st == TextToSpeech.SUCCESS) tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(id: String?) {}
                override fun onError(id: String?) { done() }
                override fun onDone(id: String?) { done() }
            })
        }
        h.post { listen() }
        return START_STICKY
    }

    private fun done() { h.post { speaking = false; h.postDelayed({ listen() }, 300) } }

    private fun lev(a: String, b: String): Int {
        val d = Array(a.length + 1) { IntArray(b.length + 1) }
        for (i in 0..a.length) d[i][0] = i
        for (j in 0..b.length) d[0][j] = j
        for (i in 1..a.length) for (j in 1..b.length)
            d[i][j] = minOf(d[i - 1][j] + 1, d[i][j - 1] + 1, d[i - 1][j - 1] + if (a[i - 1] == b[j - 1]) 0 else 1)
        return d[a.length][b.length]
    }

    /** If one of the first 3 words sounds like "Sree", returns the rest of the sentence, else null. */
    private fun wakeRest(t: String): String? {
        val w = t.split(Regex("\\s+")).filter { it.isNotEmpty() }
        for (i in 0 until minOf(3, w.size)) {
            val x = w[i].trim(',', '.', '!', '?')
            val hit = x in wakeWords || (x.length >= 3 && x.all { it in 'a'..'z' } && (lev(x, "sree") <= 1 || lev(x, "shree") <= 1 || lev(x, "siri") <= 1))
            if (hit) return w.drop(i + 1).joinToString(" ")
        }
        return null
    }

    private fun listen() {
        if (!on || speaking || busy) return
        sr?.destroy()
        sr = SpeechRecognizer.createSpeechRecognizer(this)
        sr?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(p: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(v: Float) {}
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onError(e: Int) {
                if (speaking || busy) return
                val quick = e == SpeechRecognizer.ERROR_NO_MATCH || e == SpeechRecognizer.ERROR_SPEECH_TIMEOUT
                h.postDelayed({ listen() }, if (quick) 250 else 1500)
            }
            override fun onResults(r: Bundle?) {
                r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let { handle(it.lowercase()) }
                if (!speaking && !busy) h.postDelayed({ listen() }, 250)
            }
            override fun onPartialResults(p: Bundle?) {}
            override fun onEvent(t: Int, p: Bundle?) {}
        })
        Quiet.mute(this)
        sr?.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN"))
        h.postDelayed({ Quiet.unmute(this) }, 900)
    }

    private fun handle(t: String) {
        val now = System.currentTimeMillis()
        val rest = wakeRest(t)
        val cmd = when {
            rest != null -> rest
            now < convoUntil -> t
            else -> return
        }
        convoUntil = now + 20000
        if (cmd.isBlank()) { reply("जी, बोलिए।"); return }
        if (Regex("^(bas|stop|bye|exit|ruko|band karo|बस|रुको|बंद करो|अलविदा)").containsMatchIn(cmd)) { convoUntil = 0; reply("ठीक है।"); return }
        val local = Commands.run(this, cmd)
        if (local != null) { reply(local); return }
        if (!Ai.ready(this)) { reply("AI key nahi mili. Sree app kholkar AI setup me key daalo."); return }
        busy = true
        Thread {
            val r = Ai.ask(this, cmd)
            h.post { busy = false; convoUntil = System.currentTimeMillis() + 20000; reply(r) }
        }.start()
    }

    private fun reply(text: String) {
        speaking = true
        sr?.cancel()
        tts?.language = if (text.any { it in '\u0900'..'\u097F' }) Locale("hi", "IN") else Locale("en", "IN")
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "s")
    }

    override fun onDestroy() {
        on = false; h.removeCallbacksAndMessages(null); sr?.destroy(); tts?.shutdown(); super.onDestroy()
    }
}
