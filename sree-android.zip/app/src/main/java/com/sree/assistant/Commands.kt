package com.sree.assistant

import android.Manifest
import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.provider.AlarmClock
import android.provider.MediaStore
import android.provider.Settings
import android.telephony.SmsManager
import androidx.core.content.ContextCompat

object Commands {
    private fun start(c: Context, i: Intent): Boolean {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try { c.startActivity(i); true } catch (e: Exception) { false }
    }
    private fun granted(c: Context, p: String) = ContextCompat.checkSelfPermission(c, p) == PackageManager.PERMISSION_GRANTED

    @Suppress("DEPRECATION")
    private fun smsManager(c: Context): SmsManager =
        if (Build.VERSION.SDK_INT >= 31) c.getSystemService(SmsManager::class.java) else SmsManager.getDefault()

    /** Returns a spoken reply if the command was a phone action, else null (so the app can use AI/web). */
    fun run(c: Context, raw: String): String? {
        val t = raw.lowercase().replace(Regex("^(hey |hi |ok )?(sree|shree|sri|siri|श्री|सिरी)[ ,]*"), "").trim()
        fun has(vararg w: String) = w.any { t.contains(it) }
        val digits = Regex("\\d{10,13}").find(t.replace(" ", ""))?.value
        val n = Regex("\\d+").find(t)?.value?.toIntOrNull()
        val off = has(" off", "band", "बंद", "bujha", "बुझा")

        if (has("flashlight", "flash light", "torch", "टॉर्च", "फ्लैशलाइट")) {
            return try {
                val cm = c.getSystemService(Context.CAMERA_SERVICE) as CameraManager
                val id = cm.cameraIdList.first { cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true }
                cm.setTorchMode(id, !off)
                if (off) "Torch band kar di." else "Torch on kar di."
            } catch (e: Exception) { "Torch nahi chal payi." }
        }
        if (has("volume", "awaaz", "आवाज")) {
            val am = c.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
            val cur = am.getStreamVolume(AudioManager.STREAM_MUSIC)
            val v = when {
                has("mute", "silent", "zero", "बंद") -> 0
                has("full", "max", "pura", "पूरा") -> max
                n != null -> n.coerceIn(0, 100) * max / 100
                has("up", "badha", "बढ़ा", "zyada", "increase") -> (cur + 2).coerceAtMost(max)
                has("down", "kam", "कम", "ghata", "घटा") -> (cur - 2).coerceAtLeast(0)
                else -> -1
            }
            if (v >= 0) { am.setStreamVolume(AudioManager.STREAM_MUSIC, v, AudioManager.FLAG_SHOW_UI); return "Volume set kar diya." }
        }
        if (has("brightness", "ब्राइटनेस", "roshni", "रोशनी")) {
            if (!Settings.System.canWrite(c)) {
                start(c, Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:" + c.packageName)))
                return "Pehle Sree ko Modify system settings allow karo, phir dobara bolo."
            }
            val pct = when { has("full", "max", "pura", "पूरा") -> 100; has("low", "kam", "कम", "dim") -> 15; n != null -> n.coerceIn(1, 100); else -> 60 }
            Settings.System.putInt(c.contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
            Settings.System.putInt(c.contentResolver, Settings.System.SCREEN_BRIGHTNESS, pct * 255 / 100)
            return "Brightness $pct% kar di."
        }
        if (has("wifi", "wi-fi", "वाईफाई", "वाई-फाई")) {
            start(c, Intent(if (Build.VERSION.SDK_INT >= 29) Settings.Panel.ACTION_INTERNET_CONNECTIVITY else Settings.ACTION_WIFI_SETTINGS))
            return "Wi-Fi ka panel khol diya, wahan switch dabao. Android seedha on off nahi karne deta."
        }
        if (has("bluetooth", "ब्लूटूथ")) {
            start(c, Intent(Settings.ACTION_BLUETOOTH_SETTINGS))
            return "Bluetooth settings khol di, wahan switch dabao."
        }
        if (has("call", "कॉल", "phone lagao", "फोन लगाओ") && digits != null && !has("whatsapp")) {
            return if (granted(c, Manifest.permission.CALL_PHONE)) {
                start(c, Intent(Intent.ACTION_CALL, Uri.parse("tel:$digits"))); "Call laga rahi hoon $digits"
            } else {
                start(c, Intent(Intent.ACTION_DIAL, Uri.parse("tel:$digits"))); "Call permission nahi mili, dialer khol diya."
            }
        }
        if (has("sms", "एसएमएस")) {
            val m = Regex("(\\d{10,13})\\s+(.+)").find(t)
            if (m != null && granted(c, Manifest.permission.SEND_SMS)) {
                return try { smsManager(c).sendTextMessage(m.groupValues[1], null, m.groupValues[2], null, null); "SMS bhej diya." } catch (e: Exception) { "SMS nahi gaya." }
            }
            return "SMS ke liye aise bolo: sms 9876543210 aapka message. Aur SMS permission allow rakho."
        }
        val um = Regex("(\\d+)\\s*(second|sec|सेकंड|minute|min|मिनट|hour|ghante|ghanta|घंटे|घंटा)").find(t)
        if (has("timer", "टाइमर", "remind", "yaad dila", "याद दिला") && um != null) {
            val k = um.groupValues[1].toInt(); val u = um.groupValues[2]
            val sec = k * (if (u.startsWith("sec") || u.startsWith("सेक")) 1 else if (u.startsWith("hour") || u.startsWith("gh") || u.startsWith("घं")) 3600 else 60)
            val label = t.replace(um.value, "").replace(Regex("timer|टाइमर|remind|yaad dila(na|o)?|याद दिला\\w*|baad|बाद|laga(o)?"), "").trim().ifEmpty { "Sree" }
            start(c, Intent(AlarmClock.ACTION_SET_TIMER).putExtra(AlarmClock.EXTRA_LENGTH, sec).putExtra(AlarmClock.EXTRA_MESSAGE, label).putExtra(AlarmClock.EXTRA_SKIP_UI, true))
            return "Timer laga diya: $k ${um.groupValues[2]}."
        }
        val tm = Regex("(\\d{1,2})(?::(\\d{2}))?\\s*(baje|am|pm|बजे)").find(t)
        if (has("alarm", "अलार्म", "remind", "yaad dila", "याद दिला") && tm != null) {
            var h = tm.groupValues[1].toInt(); val mi = tm.groupValues[2].ifEmpty { "0" }.toInt()
            if (h < 12 && has("pm", "shaam", "sham", "शाम", "raat", "रात", "dopahar", "दोपहर")) h += 12
            start(c, Intent(AlarmClock.ACTION_SET_ALARM).putExtra(AlarmClock.EXTRA_HOUR, h).putExtra(AlarmClock.EXTRA_MINUTES, mi).putExtra(AlarmClock.EXTRA_MESSAGE, "Sree").putExtra(AlarmClock.EXTRA_SKIP_UI, true))
            return "Phone ka alarm set: %02d:%02d".format(h, mi)
        }
        if (has("photo kheench", "photo khinch", "selfie", "camera kholo", "take photo", "take a photo", "फोटो खींच", "कैमरा")) {
            start(c, Intent(MediaStore.ACTION_IMAGE_CAPTURE)); return "Camera khol diya, shutter dabao."
        }
        if (has("screenshot", "स्क्रीनशॉट")) {
            val a = SreeAccess.inst
            return if (a != null) { a.performGlobalAction(AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT); "Screenshot le liya." }
            else { start(c, Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)); "Accessibility me Sree service on karo, phir dobara bolo." }
        }
        return null
    }
}
