package com.sree.assistant

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object Ai {
    private val hist = ArrayList<Pair<String, String>>()
    private fun prefs(c: Context) = c.getSharedPreferences("sree", Context.MODE_PRIVATE)

    fun save(c: Context, p: String, k: String, m: String) { prefs(c).edit().putString("p", p).putString("key", k).putString("m", m).apply() }
    fun ready(c: Context) = !prefs(c).getString("key", "").isNullOrEmpty()

    private fun post(url: String, headers: Map<String, String>, body: String): String {
        val cn = URL(url).openConnection() as HttpURLConnection
        cn.requestMethod = "POST"; cn.connectTimeout = 15000; cn.readTimeout = 30000; cn.doOutput = true
        cn.setRequestProperty("Content-Type", "application/json")
        headers.forEach { (k, v) -> cn.setRequestProperty(k, v) }
        cn.outputStream.use { it.write(body.toByteArray()) }
        val code = cn.responseCode
        val txt = (if (code in 200..299) cn.inputStream else cn.errorStream).bufferedReader().use { it.readText() }
        if (code !in 200..299) throw Exception(txt.take(200))
        return txt
    }

    /** Blocking call: run on a background thread. */
    fun ask(c: Context, q: String): String {
        val p = prefs(c)
        val key = p.getString("key", "") ?: ""
        val prov = p.getString("p", "gemini") ?: "gemini"
        val model = p.getString("m", "") ?: ""
        val sys = "You are Sree, a friendly voice assistant in a live voice conversation. Reply in the user's language (Hindi in Devanagari, Hinglish or English) in 1 to 3 short spoken sentences. No markdown, no lists."
        hist.add("user" to q); while (hist.size > 12) hist.removeAt(0)
        return try {
            val out = if (prov == "gemini") {
                val contents = JSONArray()
                hist.forEach { (r, t) -> contents.put(JSONObject().put("role", r).put("parts", JSONArray().put(JSONObject().put("text", t)))) }
                val body = JSONObject().put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", sys)))).put("contents", contents).toString()
                val m = model.ifEmpty { "gemini-2.5-flash" }
                JSONObject(post("https://generativelanguage.googleapis.com/v1beta/models/$m:generateContent", mapOf("x-goog-api-key" to key), body))
                    .getJSONArray("candidates").getJSONObject(0).getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
            } else {
                val msgs = JSONArray().put(JSONObject().put("role", "system").put("content", sys))
                hist.forEach { (r, t) -> msgs.put(JSONObject().put("role", if (r == "user") "user" else "assistant").put("content", t)) }
                val body = JSONObject().put("model", model.ifEmpty { "llama-3.3-70b-versatile" }).put("messages", msgs).toString()
                JSONObject(post("https://api.groq.com/openai/v1/chat/completions", mapOf("Authorization" to "Bearer $key"), body))
                    .getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content")
            }.trim()
            hist.add("model" to out); out
        } catch (e: Exception) { hist.removeAt(hist.size - 1); "AI se jawab nahi mila. Internet ya key check karo." }
    }
}
